//
//  PokemonsTypes.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 29/05/26.
//

import Foundation

// MARK: - TypeElement
struct TypeElement: Codable {
    let slot: Int
    let type: Species
}

// MARK: - Species
struct Species: Codable {
    let name: String
    let url: String
}

