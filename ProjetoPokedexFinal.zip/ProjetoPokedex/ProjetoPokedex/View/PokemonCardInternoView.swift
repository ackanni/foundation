//
//  PokemonCardInternoView.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 27/05/26.
//

import SwiftUI

struct PokemonCardInternoView: View {
    let pokemon: Pokemon
    @State private var tipos: [Species]? = []
    @Binding var pokemonsCapturados: Set<Int>
    
    private var isCaptured: Bool {
        pokemonsCapturados.contains(pokemon.id)
    }
    
    var body: some View {
        VStack{
            
            if let image = pokemon.sprites.other?.officialArtwork?.frontDefault {
                AsyncImage(url: URL(string: image)) { sprite in
                    sprite
                        .resizable()
                        .scaledToFit()
                    //                        .frame(width: 350, height: 350)
                        .containerRelativeFrame(.horizontal) { width, _ in
                            width * 0.8
                        }
                    //                        .padding(10)
                } placeholder: {
                    ProgressView()
                }
                
            } else {
                Image(systemName: "cat")
                    .font(.largeTitle)
                    .frame(width: 110, height: 80)
                    .background(.red)
                    .padding(10)
                    .foregroundColor(.white)
            }
            
            
            HStack{
                
                Text(pokemon.name.capitalized)
                    .foregroundStyle(.black)
                    .bold()
                    .font(.title)
                
                Button(action: {
                    let id = pokemon.id
                    
                    if pokemonsCapturados.contains(id) {
                        pokemonsCapturados.remove(id)
                    } else {
                        pokemonsCapturados.insert(pokemon.id)
                    }
                    
                    
                }) {
                    if isCaptured {
                        ZStack{
                            Circle()
                                .foregroundColor(.blue)
                                .frame(width: 30, height: 30)
                            Image(systemName: "minus")
                                .foregroundStyle(.white)
                        }
                        
                    } else {
                        ZStack{
                            Circle()
                                .foregroundColor(.gray)
                                .frame(width: 30, height: 30)
                            Image(systemName: "plus")
                                .foregroundStyle(.white)
                        }
                    }
                }
            }
        }
        VStack (alignment: .leading){
            Text("Tipos Principal: \(pokemon.types[0].type.name)")
                .bold()
            if pokemon.types.count > 1 {
                Text("Tipos Secundario: \(pokemon.types[1].type.name)")
                    .bold()
            }
        }
    }
}
