//
//  PokemonsPrincipal.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 27/05/26.
//

import SwiftUI

struct PokemonsPrincipal: View {
    @State private var listaPokemons: [Pokemon]? = []
    let colunas = [GridItem(.adaptive(minimum: 120), spacing: 7)]
    @State private var pokemonsCapturados = Set<Int>()    
    
    let filtro: Filter
    
    var ownedPokemons: [Pokemon] {
        (listaPokemons ?? []).filter { pokemon in
            pokemonsCapturados.contains(pokemon.id)
        }
    }
    
    var notownedPokemons:  [Pokemon] {
        (listaPokemons ?? []).filter { pokemon in
            !pokemonsCapturados.contains(pokemon.id)
        }
    }
    
    var body: some View {
        
        VStack{
            
            
            ScrollView{
                
                if let listaPokemons {
          
                    LazyVGrid(columns: colunas, spacing: 20){
                        switch filtro {
                        case .todos:
                            ForEach(listaPokemons) { pokemon in
                                NavigationLink{
                                    PokemonCardInternoView(pokemon: pokemon, pokemonsCapturados: $pokemonsCapturados)
                                } label: {
                                    PokemonsCardView(pokemon: pokemon)
                                }
                            }
                        case .owned:
                            ForEach(ownedPokemons) { pokemon in
                                NavigationLink{
                                    PokemonCardInternoView(pokemon: pokemon, pokemonsCapturados: $pokemonsCapturados)
                                } label: {
                                    PokemonsCardView(pokemon: pokemon)
                                }
                            }
                        case .notOwned:
                            ForEach(notownedPokemons) { pokemon in
                                NavigationLink{
                                    PokemonCardInternoView(pokemon: pokemon, pokemonsCapturados: $pokemonsCapturados)
                                } label: {
                                    PokemonsCardView(pokemon: pokemon)
                                }
                            }
                        }
       
                    }
                } else{
                    Text("Erro ao carregar lista Pokemon")
                }
            }
        }
        .task {
            listaPokemons = try? await PokemonAPI.fetchPokemon(limit: 21)
        }
    }
        
}

