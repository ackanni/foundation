//
//  Interface.swift
//  Aula01
//
//  Created by Aluno Mack on 22/05/26.
//

import SwiftUI

struct Interface: View {
    //arraylist
    
    @State private var filtro = Filter.todos
    @State private var guardarBusca: String = ""
    
//    private func acharBusca() {
//        
//    }
    
    var body: some View {
        TabView {
            //brainstorm da view: 3 principais componentes VStacked;
            //componente 1(barra de pesquisa no topo),
            //componente 2(sub componente HStacked -> 3 botões de filtro para exibicão dos pokemons),
            //componente 3(secão com os pokemons propriamente ditos[icon e nome] -> qual Stack?)
            
            //primeira view
            NavigationStack {
                
                FiltroCardView(filtro: $filtro)
                PokemonsPrincipal(filtro: filtro)
                
                
                .searchable(text: $guardarBusca, prompt: "Pokemon")
                
            }
            
            .tabItem{
                Label("My Pokémon", systemImage: "pawprint.circle")
            }
            
            //segunda view
            Text("Battle simulation")
                .tabItem {
                    Label("Battlefield", systemImage: "dumbbell.fill")
                }
            //fecha vstack
        }//fecha tabview
    }//fecha body
}

#Preview {
    Interface()
}

enum Filter{
    case todos
    case owned
    case notOwned
}
