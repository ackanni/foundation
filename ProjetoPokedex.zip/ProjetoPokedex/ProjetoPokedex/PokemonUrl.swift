//
//  PokemonUrl.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 26/05/26.
//

import Foundation

struct PokemonUrl: Decodable{
    let name: String
    let url: String
}
