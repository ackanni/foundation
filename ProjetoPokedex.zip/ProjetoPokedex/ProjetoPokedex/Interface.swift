//
//  Interface.swift
//  Aula01
//
//  Created by Aluno Mack on 22/05/26.
//

import SwiftUI

struct Interface: View {
    //arraylist
    @State private var listaPokemons: [Pokemon]? = []
    
    enum filter{
        case todos
        case owned
        case notOwned
    }
    
    let colunas = [GridItem(.adaptive(minimum: 100), spacing: 15)]
    
    var body: some View {
        TabView {
            //brainstorm da view: 3 principais componentes VStacked;
            //componente 1(barra de pesquisa no topo),
            //componente 2(sub componente HStacked -> 3 botões de filtro para exibicão dos pokemons),
            //componente 3(secão com os pokemons propriamente ditos[icon e nome] -> qual Stack?)
            
            //primeira view
            NavigationStack {
                VStack{
                    //colocar a searchbar aqui (componente1)
                    
                    //filtros aqui(componente 2)
                    HStack{
                        Button("All"){
                            //show all
                        }
                        .frame(width: 110, height: 35)
                        .background(.red)
                        .clipShape(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/))
                        .foregroundStyle(.white)
                        .bold()

                        
                        Button("Owned"){
                            //show owned
                        }
                        .frame(width: 110, height: 35)
                        .background(.red)
                        .clipShape(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/))
                        .foregroundStyle(.white)
                        .bold()
                        
                        Button("Not Owned"){
                            //show not owned
                        }
                        .frame(width: 110, height: 35)
                        .background(.red)
                        .clipShape(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/))
                        .foregroundStyle(.white)
                        .bold()
                        
                    }
                    ScrollView{
                        if let listaPokemons{
                        LazyVGrid(columns: colunas, spacing: 20){
                            ForEach(listaPokemons) { pokemon in //trocar Pokemon.sampleData pela lista de pokemon
                                NavigationLink{
                                    VStack{
                                        Image(systemName: "car")
                                            .font(.largeTitle)
                                            .frame(width: 450, height: 300)
                                            .background(.red)
                                            .padding(10)
                                            .foregroundColor(.white)
                                        Text(pokemon.nome)
                                    }
                                } label: {
                                    VStack{
                                        Image(systemName: "car")
                                            .font(.largeTitle)
                                            .frame(width: 110, height: 80)
                                            .background(.red)
                                            .padding(10)
                                            .foregroundColor(.white)
                                        Text(pokemon.nome)
                                            .foregroundStyle(.red)
                                            .bold()
                                    }
                                }
                            }
                            }
                        } else{
                            ProgressView()
                        }
                    }
                }
//                .navigationTitle("Pokemon")
                .searchable(text: .constant("dsadas"))
                .task {
                    listaPokemons = try? await PokemonAPI.fetchPokemonId()
                }
            }
            
            //ideia: escurecer levemente a cor da secão dos tabItem para indicar delimitacões
                .tabItem{
                    Label("My Pokémon", systemImage: "car")
                }
            
            //segunda view
            Text("Battle simulation")
                .tabItem {
                    Label("Battlefield", systemImage: "person")
                }
            //fecha vstack
        }//fecha tabview
    }//fecha body
}

#Preview {
    Interface()
}
