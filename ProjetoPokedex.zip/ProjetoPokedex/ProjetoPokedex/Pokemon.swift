//
//  Pokemon.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 22/05/26.
//

import Foundation

struct Pokemon: Codable{
    let id: Int
    let name: String
    
    
    static let sampleData: [Pokemon] = [
        Pokemon(id: 1, name: "Pikachu"),
        Pokemon(id: 2, name: "Charmander"),
        Pokemon(id: 4, name: "Bulbassaur"),
        Pokemon(id: 3, name: "Squirtle")
    ]

}
