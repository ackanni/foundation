//
//  PokemonAPI.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 25/05/26.
//

import Foundation

struct PokemonAPI{
    static let endpoint = URL(string: "https://pokeapi.co/api/v2/")!
    
    
    

    
    //aula passada
    static func fetchPokemon(limit: Int = 151) async throws -> [Pokemon]{
        //definindo um endpoint geral
        let url = URL(string: "https://pokeapi.co/api/v2/pokemon/?limit=\(151)")!
        
        //fazendo a requisicao
        let request = URLRequest(url: url)
        
        //'_'é para os metadados
        let (PokemonResultsRawData, _) = try await URLSession.shared.data(for: request)
        
        let pokemonResultsDecodado = try JSONDecoder().decode(PokemonResults.self, from: PokemonResultsRawData) //decodando o pacote recebido em JSON
        
        //lista pra guardar pokemons Pokemon
        let pokemonListExemplo: [Pokemon] = []
        
        for pokemonResult in pokemonResultsDecodado.result {
            let requestResults = URLRequest(url: URL(string: pokemonResult.url)!)
            
            let (data, _) = URLSession.shared.data(for: requestResults)
            
            let pokemon = JSONDecoder().decode(Pokemon.self, from: data)
            
            pokemonListExemplo.append(pokemon)
        }
        
        return pokemonListExemplo
        
        
    }
}




