//
//  PokemonsSprites.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 27/05/26.
//

import Foundation
struct PokemonsSprites: Codable{
    let backDefault: String?
    let backFemale: String?
    let backShinyFemale: String?
    let frontDefault: String?
    let frontFemale: String?
    let frontShiny: String?
    let frontShinyFemale: String?
    let other: PokemonsOthers?
}
struct PokemonsOthers: Codable  {
    let officialArtwork: OfficialArtwork?
    
    enum CodingKeys: String, CodingKey {
            case officialArtwork = "official-artwork"
        }
    
    
    
    
}
struct OfficialArtwork: Codable{
    let frontDefault: String?
    let frontShiny: String?
}
