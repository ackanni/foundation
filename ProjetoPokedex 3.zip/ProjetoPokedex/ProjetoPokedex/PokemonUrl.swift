//
//  PokemonUrl.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 26/05/26.
//

import Foundation

struct PokemonURL: Decodable{
    let name: String
    let url: String
}
