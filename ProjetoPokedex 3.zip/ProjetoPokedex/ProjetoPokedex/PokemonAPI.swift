//
//  PokemonAPI.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 25/05/26.
//

import Foundation

struct PokemonAPI{
    static let endpoint = URL(string: "https://pokeapi.co/api/v2/")! //linkagem da api
    
    static var decoder: JSONDecoder{
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return decoder
    }
    
   static func fetchPokemon(limit: Int = 151) async throws -> [Pokemon]{
        //definindo um endpoint geral
        let url = URL(string: "https://pokeapi.co/api/v2/pokemon/?limit=\(limit)")!
    
        //fazendo a requisicao
       let request = URLRequest(url: url, cachePolicy: .returnCacheDataElseLoad)
        
        //'_'é para os metadados
        let (pokemonResultsRawData, _) = try await URLSession.shared.data(for: request)
        
        let pokemonResultsDecodado = try decoder.decode(PokemonResults.self, from: pokemonResultsRawData) //decodando o pacote recebido em JSON
        
        //lista pra guardar pokemons Pokemon
        var pokemonListExemplo: [Pokemon] = []
        
        for pokemonResult in pokemonResultsDecodado.results {
            let requestResults = URLRequest(url: URL(string: pokemonResult.url)!)
            
            let (data, _) = try await URLSession.shared.data(for: requestResults)
            
            let pokemon = try decoder.decode(Pokemon.self, from: data)
            
            pokemonListExemplo.append(pokemon)
        }
        
        return pokemonListExemplo
        
        
    }
}




