//
//  ProjetoPokedexApp.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 22/05/26.
//

import SwiftUI

@main
struct ProjetoPokedexApp: App {
    var body: some Scene {
        WindowGroup {
            Interface()
        }
    }
}
