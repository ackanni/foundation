//
//  ViewModel.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 26/05/26.
//

import Foundation

struct PokemonResults: Decodable{
    let count: Int
    let results: [PokemonURL]
}
