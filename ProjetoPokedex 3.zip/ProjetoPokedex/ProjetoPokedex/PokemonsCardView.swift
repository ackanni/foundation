//
//  PokemonsCardView.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 27/05/26.
//

import SwiftUI

struct PokemonsCardView: View {
    let pokemon: Pokemon
    var body: some View {
        
        VStack{
            
            if let image = pokemon.sprites.frontDefault {
                AsyncImage(url: URL(string: image)) { sprite in
                    sprite
                        .frame(width: 102, height: 85)
                        .padding(5)
                } placeholder: {
                    ProgressView()
                }
                
            } else {
                Image(systemName: "cat")
                    .font(.largeTitle)
                    .frame(width: 110, height: 80)
                    .background(.red)
                    .padding(10)
                    .foregroundColor(.white)
            }
            
            
            
            Text(pokemon.name.capitalized)
                .foregroundStyle(.red)
                .bold()
                .padding(.bottom, 5)
        }
        .padding(.horizontal, 3)
        .clipShape(RoundedRectangle(cornerRadius: 25))
        .border(Color.red, width: 3)
        
        
    }
}
