//
//  PokemonCardInternoView.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 27/05/26.
//

import SwiftUI

struct PokemonCardInternoView: View {
    let pokemon: Pokemon
    @Binding var pokemonsCapturados: Set<Int>
    
    private var isCaptured: Bool {
        pokemonsCapturados.contains(pokemon.id)
    }
    
    var body: some View {
        VStack{
            
            if let image = pokemon.sprites.other?.officialArtwork?.frontDefault {
                AsyncImage(url: URL(string: image)) { sprite in
                    sprite
                        .resizable()
                        .scaledToFit()
//                        .frame(width: 350, height: 350)
                        .containerRelativeFrame(.horizontal) { width, _ in
                            width * 0.8
                        }
//                        .padding(10)
                } placeholder: {
                    ProgressView()
                }
                
            } else {
                Image(systemName: "cat")
                    .font(.largeTitle)
                    .frame(width: 110, height: 80)
                    .background(.red)
                    .padding(10)
                    .foregroundColor(.white)
            }
            
            
            HStack{
                Text(pokemon.name.capitalized)
                    .foregroundStyle(.red)
                    .bold()
                
                Button(action: {
                    let id = pokemon.id
                    
                    if pokemonsCapturados.contains(id) {
                        pokemonsCapturados.remove(id)
                    } else {
                        pokemonsCapturados.insert(pokemon.id)
                    }
                    
                    
                }) {
                    if isCaptured {
                        Circle()
                        	.foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                        	.frame(width: 30, height: 30)
                    } else{
                        Circle()
                            .foregroundColor(.gray)
                        	.frame(width: 30, height: 30)
                    }
                }
//
//                    .frame(width: 0, height: 35)
//                    .background(.red)
//                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
//                    .foregroundStyle(.white)
//                    .bold()
                    
            }
            
            
            
            
        }
    }
}
