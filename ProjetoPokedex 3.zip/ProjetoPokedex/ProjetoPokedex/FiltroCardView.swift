//
//  FiltroCardView.swift
//  ProjetoPokedex
//
//  Created by Aluno Mack on 27/05/26.
//

import SwiftUI

struct FiltroCardView: View {
    @Binding var filtro: Filter
    
    var body: some View {
        HStack{
            Button {
                filtro = .todos
            } label: {
                Text("All")
                    .frame(width: 110, height: 35)
                    .background(filtro == .todos ? .red : .gray)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .foregroundStyle(.white)
                    .bold()
            }
            
            Button {
                filtro = .owned
            } label: {
                Text("Owned")
                    .frame(width: 110, height: 35)
                    .background(filtro == .owned ? .red : .gray)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .foregroundStyle(.white)
                    .bold()
            }
            
            Button {
                filtro = .notOwned
            } label: {
                Text("Not Owned")
                    .frame(width: 110, height: 35)
                    .background(filtro == .notOwned ? .red : .gray)
                    .clipShape(RoundedRectangle(cornerRadius: 25.0))
                    .foregroundStyle(.white)
                    .bold()
            }
        }
    }
}

